﻿
$DesktopPath = (Get-ItemProperty -Path "Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders").Desktop

$ShortcutPath = "$($DesktopPath)\Kill Steam.lnk"
$ApplicationPath = "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"
$IconLocation = "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"

$WScriptShell = New-Object -ComObject WScript.Shell
$Shortcut = $WScriptShell.CreateShortcut($ShortcutPath)
$Shortcut.TargetPath = "$ApplicationPath"
$Shortcut.Arguments = "-ExecutionPolicy Bypass -WindowStyle Hidden -Command Stop-Process -Name `"*steam*`" -Confirm:`$False -Force -ErrorAction SilentlyContinue"
$shortcut.IconLocation = "$IconLocation,0"
$Shortcut.Save()

$ShortcutBytes = [System.IO.File]::ReadAllBytes("$($DesktopPath)\Kill Steam.lnk")
$ShortcutBytes[0x15] = $ShortcutBytes[0x15] -bor 0x20 #set byte 21 (0x15) bit 6 (0x20) ON
[System.IO.File]::WriteAllBytes("$($DesktopPath)\Kill Steam.lnk", $ShortcutBytes)